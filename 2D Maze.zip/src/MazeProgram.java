import java.awt.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;
public class MazeProgram extends JPanel implements KeyListener,MouseListener {
	JFrame frame;

	ArrayList<ArrayList<String>> maze = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<Boolean>> appear = new ArrayList<ArrayList<Boolean>>();
	int sX,sY;
	boolean forward, left, right;
	Image[] pic =  {new ImageIcon(this.getClass().getResource("up.png")).getImage(),
					new ImageIcon(this.getClass().getResource("arrow.png")).getImage(),
					new ImageIcon(this.getClass().getResource("aDown.png")).getImage(),
					new ImageIcon(this.getClass().getResource("left.png")).getImage()};
	public int direction = 1;
	public int moves = 0;
	public boolean win = false;
	public boolean play = true;
	int locX = 0;
	int locY = 0;

	public MazeProgram() {
		setBoard();
		frame=new JFrame();
		frame.add(this);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1900,1080);
		frame.setVisible(true);
		frame.addKeyListener(this);
	}

	public void paintComponent(Graphics game) {
		super.paintComponent(game);
		game.setColor(Color.BLACK);
		game.fillRect(0,0,1980,1080);
		game.setColor(Color.WHITE);
		int size = 27;
		int start = 50;

		game.setFont(new Font("Arial",Font.BOLD,25));

		if(!win && !play) {
			game.drawString("Draw The Game: Press Enter when done",10,start-20);
		}else if(!win && play) {
			game.drawString("Play The Game",10,start-20);
		}else{
			game.drawString("You Won the Game. Press R to reset",10,start-20);
		}
		game.drawString("Score: "+moves,700,start-20);

		for(int x = 0; x<maze.size(); x++){
			for (int y= 0; y<maze.get(x).size(); y++){

				if (maze.get(x).get(y).equals("-")){
					locX = x;
					locY = y;
					game.drawImage(pic[direction],y*size +1, x*size +1+start, null);
					try {
						appear.get(x - 1).set(y - 1, true);
						appear.get(x - 1).set(y, true);
						appear.get(x - 1).set(y + 1, true);
						appear.get(x).set(y - 1, true);
						appear.get(x).set(y + 1, true);
						appear.get(x + 1).set(y - 1, true);
						appear.get(x + 1).set(y, true);
						appear.get(x + 1).set(y + 1, true);
					}catch (Exception e){
						System.out.println("error");
					}
				}

				if (maze.get(x).get(y).equals("*") && appear.get(x).get(y)){
					game.setColor(Color.RED);
					game.fillRect(y*size,x*size+start,size,size);
					game.setColor(Color.BLACK);
					game.drawRect(y*size,x*size+start,size,size);
				}

				if(maze.get(x).get(y).equals("o")){
					game.setColor(Color.BLUE);
					game.fillRect(y*size +3,x*size +3+start,size-6,size-6);
				}
			}
		}
	}

	public void setBoard(){
		File name = new File("D:\\Akash's Stuff\\Computer Science\\Data Structures\\MazeProgram\\src\\maze");

		int r=0;
		try {
			BufferedReader input = new BufferedReader(new FileReader(name));
			String text;
			while( (text= input.readLine())!= null) {
				String row[] = text.split("");
				maze.add(new ArrayList<String>());
				appear.add(new ArrayList<Boolean>());
				int y = 0;
				for(String x: row){
					if(x.equals("-")){
						sX = r;
						sY = y;
					}
					y++;
					maze.get(r).add(x);
					appear.get(r).add(false);
				}
				r++;
			}
		}
		catch (IOException io){
			System.err.println("File error");
		}
	}

	public void setWalls(){
	}

	public void keyPressed(KeyEvent e) {
		if ((e.getKeyCode() == 82)) {
			maze.get(sX).set(sY,"-");
			maze.get(locX).set(locY," ");
			win = false;
			moves = 0;
		}

		if ((e.getKeyCode() == 10)) {
			maze.get(sX).set(sY,"-");
			maze.get(locX).set(locY,"o");
			win = false;
			moves = 0;
			play = true;
		}

		if(!win && play) {
			if ((e.getKeyCode() == 39)) {
				direction++;
				if (direction == 4)
					direction = 0;
				if (!win)
					moves++;
			}
			if ((e.getKeyCode() == 38)) {
				try {
					switch (direction) {
						case 0:
							if (maze.get(locX - 1).get(locY).equals(" ")) {
								maze.get(locX).set(locY, (" "));
								maze.get(locX - 1).set(locY, "-");
								if (!win)
									moves++;
							}
							if (maze.get(locX - 1).get(locY).equals("o")) {
								win = true;
							}

							break;
						case 1:
							if (maze.get(locX).get(locY + 1).equals(" ")) {
								maze.get(locX).set(locY, (" "));
								maze.get(locX).set(locY + 1, "-");
								if (!win)
									moves++;
							}
							if (maze.get(locX).get(locY + 1).equals("o")) {
								win = true;
							}
							break;
						case 2:
							if (maze.get(locX + 1).get(locY).equals(" ")) {
								maze.get(locX).set(locY, (" "));
								maze.get(locX + 1).set(locY, "-");
								if (!win)
									moves++;
							}
							if (maze.get(locX + 1).get(locY).equals("o")) {
								win = true;
							}
							break;
						case 3:
							if (maze.get(locX).get(locY - 1).equals(" ")) {
								maze.get(locX).set(locY, (" "));
								maze.get(locX).set(locY - 1, "-");
								if (!win)
									moves++;
							}
							if (maze.get(locX).get(locY - 1).equals("o")) {
								win = true;
							}
							break;
					}
				} catch (Exception ex) {
				}
			}

			if ((e.getKeyCode() == 37)) {
				direction--;
				if (!win)
					moves++;
				if (direction == -1)
					direction = 3;

			}
			repaint();
		}

		if(!win && !play) {
			if ((e.getKeyCode() == 39)) {
				direction++;
				if (direction == 4)
					direction = 0;
				if (!win)
					moves++;
			}
			if ((e.getKeyCode() == 38)) {
				try {
					switch (direction) {
						case 0:
								maze.get(locX).set(locY, (" "));
								maze.get(locX - 1).set(locY, "-");
								if (!win)
									moves++;

							if (maze.get(locX - 1).get(locY).equals("o")) {
								win = true;
							}

							break;
						case 1:
								maze.get(locX).set(locY, (" "));
								maze.get(locX).set(locY + 1, "-");
								if (!win)
									moves++;

							if (maze.get(locX).get(locY + 1).equals("o")) {
								win = true;
							}
							break;
						case 2:
								maze.get(locX).set(locY, (" "));
								maze.get(locX + 1).set(locY, "-");
								if (!win)
									moves++;

							if (maze.get(locX + 1).get(locY).equals("o")) {
								win = true;
							}
							break;
						case 3:
								maze.get(locX).set(locY, (" "));
								maze.get(locX).set(locY - 1, "-");
								if (!win)
									moves++;

							if (maze.get(locX).get(locY - 1).equals("o")) {
								win = true;
							}
							break;
					}
				} catch (Exception ex) {}

			}

			if ((e.getKeyCode() == 37)) {
				direction--;
				if (!win)
					moves++;
				if (direction == -1)
					direction = 3;

			}
			repaint();
		}
	}

	public void keyReleased(KeyEvent e) {

	}

	public void keyTyped(KeyEvent e) {
	}

	public void mouseClicked(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public static void main(String args[])
	{
		MazeProgram app=new MazeProgram();
	}
}